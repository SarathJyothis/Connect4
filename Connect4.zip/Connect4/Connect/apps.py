from django.apps import AppConfig


class ConnectConfig(AppConfig):
    name = 'Connect'
